package com.nhnacademy.edu.springframework.project.service;

import com.nhnacademy.edu.springframework.project.repository.CsvScores;
import com.nhnacademy.edu.springframework.project.repository.CsvStudents;
import com.nhnacademy.edu.springframework.project.repository.Score;
import com.nhnacademy.edu.springframework.project.repository.Student;
import java.util.Collection;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GradeQueryServiceTest {

    @DisplayName("이름이 C인 학생을 찾아봅시다")
    @Test
    void getScoreByStudentName() {
        DefaultGradeQueryService service = new DefaultGradeQueryService();
        CsvStudents.getInstance().load();
        CsvScores.getInstance().load();
        Collection<Score> scores = CsvScores.getInstance().findAll();
        CsvStudents.getInstance().merge(scores);

        System.out.println(service.getScoreByStudentName("C"));
    }

    @DisplayName("3번 학생을 찾아봅시다.")
    @Test
    void getScoreByStudentSeq() {
        DefaultGradeQueryService service = new DefaultGradeQueryService();
        CsvStudents.getInstance().load();
        CsvScores.getInstance().load();
        Collection<Score> scores = CsvScores.getInstance().findAll();
        CsvStudents.getInstance().merge(scores);

        System.out.println(service.getScoreByStudentSeq(3));
    }
}