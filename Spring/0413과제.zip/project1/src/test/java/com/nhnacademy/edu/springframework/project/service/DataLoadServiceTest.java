package com.nhnacademy.edu.springframework.project.service;

import com.nhnacademy.edu.springframework.project.repository.CsvScores;
import com.nhnacademy.edu.springframework.project.repository.CsvStudents;
import com.nhnacademy.edu.springframework.project.repository.Score;
import java.util.Collection;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataLoadServiceTest {

    @Test
    void loadAndMerge() {
        CsvStudents.getInstance().load();
        CsvScores.getInstance().load();
        Collection<Score> scores = CsvScores.getInstance().findAll();
        CsvStudents.getInstance().merge(scores);
    }
}