package com.nhnacademy.edu.springframework.project.repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class StudentsTest {

    @Test
    void load() {
        CsvStudents.getInstance().load();
    }

    @Test
    void findAll() {
        CsvStudents.getInstance().findAll();
    }

    @Test
    void merge() {
        CsvStudents.getInstance().load();
        CsvScores.getInstance().load();
        Collection<Score> scores = CsvScores.getInstance().findAll();
        CsvStudents.getInstance().merge(scores);

        for (Student student : CsvStudents.getInstance().findAll()) {
            System.out.println(student.toString());
        }
    }
}