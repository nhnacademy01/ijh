package com.nhnacademy.edu.springframework.project.repository;

import java.util.List;
import org.junit.jupiter.api.Test;

class ScoresTest {

    @Test
    void load() {
        CsvScores.getInstance().load();
    }

    @Test
    void findAll() {
        List<Score> list = CsvScores.getInstance().findAll();
        for (Score score : list) {
            System.out.println("번호 : " + score.getStudentSeq() + " 점수 : " + score.getScore());
        }
    }
}