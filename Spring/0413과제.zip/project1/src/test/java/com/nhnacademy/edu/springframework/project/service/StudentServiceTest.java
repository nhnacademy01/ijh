package com.nhnacademy.edu.springframework.project.service;

import com.nhnacademy.edu.springframework.project.repository.CsvScores;
import com.nhnacademy.edu.springframework.project.repository.CsvStudents;
import com.nhnacademy.edu.springframework.project.repository.Score;
import com.nhnacademy.edu.springframework.project.repository.Student;
import java.util.Collection;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentServiceTest {

    @DisplayName("통과한 학생들을 출력합니다.")
    @Test
    void getPassedStudents() {
        DefaultStudentService service = new DefaultStudentService();
        CsvStudents.getInstance().load();
        CsvScores.getInstance().load();
        Collection<Score> scores = CsvScores.getInstance().findAll();
        CsvStudents.getInstance().merge(scores);

        for (Student student : service.getPassedStudents()) {
            System.out.println(student.toString());
        }
    }

    @DisplayName("성적순으로 학생을 정렬합시다.")
    @Test
    void getStudentsOrderByScore() {
        DefaultStudentService service = new DefaultStudentService();
        CsvStudents.getInstance().load();
        CsvScores.getInstance().load();
        Collection<Score> scores = CsvScores.getInstance().findAll();
        CsvStudents.getInstance().merge(scores);

        for (Student student : service.getStudentsOrderByScore()) {
            System.out.println(student.toString());
        }

    }
}