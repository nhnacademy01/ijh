package com.nhnacademy.edu.springframework.project.service;

import com.nhnacademy.edu.springframework.project.repository.CsvStudents;
import com.nhnacademy.edu.springframework.project.repository.Student;
import com.nhnacademy.edu.springframework.project.repository.Students;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DefaultStudentService implements StudentService {
    ArrayList<String> strings = new ArrayList<>();


    @Override
    public Collection<Student> getPassedStudents() {
        Students studentRepository = CsvStudents.getInstance();
        // DONE 1 : pass 한 학생만 반환하도록 수정하세요.
        Map<Integer,Student> students = new HashMap<>();

        for (Student student : studentRepository.findAll()) {
            if (!student.getScore().isFail()) {
                students.put(student.getSeq(), student);
            }
        }

        return students.values();
    }

    @Override
    public Collection<Student> getStudentsOrderByScore() {
        Students studentRepository = CsvStudents.getInstance();
        // DONE 4 : 성적 순으로 학생 정보를 반환합니다.
        List<Student> studentList = new ArrayList<>(studentRepository.findAll());
        List<Student> sortedStudentList = new ArrayList<>();

        studentList.stream()
            .sorted(Comparator.comparing((Student s) -> s.getScore().getScore()))
            .forEach(sortedStudentList::add);

        return sortedStudentList;
    }
}
