package com.nhnacademy.repository;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

class RepositoryTest {
    List<Data> dataList = new ArrayList<>();
    String filePath = "src/main/resources/data/Tariff_20220331.csv";


    @BeforeEach
    void setUp() {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.nhnacademy")) {
            DataParser csvDataParser = context.getBean("csvDataParser", CsvDataParser.class);
            dataList = csvDataParser.parse(filePath);
        }
    }

    @DisplayName("Data 가 FeeTable 에 잘 저장되어 있다.")
    @Test
    void data_isNotNull() {
        assertNotNull(dataList);
    }
}