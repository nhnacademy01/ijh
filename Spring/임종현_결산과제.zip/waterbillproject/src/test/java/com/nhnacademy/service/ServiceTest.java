package com.nhnacademy.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.nhnacademy.repository.Data;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

class ServiceTest {
    WaterBillService defaultWaterBillService;

    @BeforeEach
    void setup() {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.nhnacademy")) {
            defaultWaterBillService = context.getBean("defaultWaterBillService",
                DefaultWaterBillService.class);
        }
    }

    @DisplayName("유저가 사용한 양만큼 계산이 잘 되었다.")
    @Test
    void calculationPay() {
        int usage = 1000;
        List<Data> list = defaultWaterBillService.calculationPay(usage);
        assertThat(list).hasSize(5);
    }
}