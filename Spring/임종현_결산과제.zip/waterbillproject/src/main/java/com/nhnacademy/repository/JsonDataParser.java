package com.nhnacademy.repository;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Repository;

@Repository
public class JsonDataParser implements DataParser{
    private final List<Data> dataList = new ArrayList<>();

    @Override
    public List<Data> parse(String filePath) {
        JSONParser parser = new JSONParser();

        try (Reader reader = new FileReader(filePath)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            List<JSONObject> jsonObjList = new ArrayList<>();

            for (Object obj : jsonArray) {
                jsonObjList.add((JSONObject) obj);
            }

            for (JSONObject jsonObject : jsonObjList) {
                dataList.add(new Data(
                    Math.toIntExact((Long) jsonObject.get("순번")),
                    (String) jsonObject.get("지자체명"),
                    (String) jsonObject.get("업종"),
                    Math.toIntExact((Long) jsonObject.get("단계")),
                    Math.toIntExact((Long) jsonObject.get("구간시작(세제곱미터)")),
                    Math.toIntExact((Long) jsonObject.get("구간끝(세제곱미터)")),
                    Math.toIntExact((Long) jsonObject.get("구간금액(원)")),
                    Math.toIntExact((Long) jsonObject.get("단계별 기본요금(원)"))
                    ));
            }

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }

        return dataList;
    }
}
