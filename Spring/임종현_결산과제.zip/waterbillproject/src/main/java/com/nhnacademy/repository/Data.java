package com.nhnacademy.repository;

public class Data {
    private final int seq;
    private final String city;
    private final String sector;
    private final int step;
    private final int sectionStart;
    private final int sectionEnd;
    private final int unitPrice;
    private final int billTotal;

    public Data(int seq, String city, String sector, int step, int sectionStart, int sectionEnd,
                int unitPrice, int billTotal) {
        this.seq = seq;
        this.city = city;
        this.sector = sector;
        this.step = step;
        this.sectionStart = sectionStart;
        this.sectionEnd = sectionEnd;
        this.unitPrice = unitPrice;
        this.billTotal = billTotal;
    }

    public int getSeq() {
        return seq;
    }

    public int getStep() {
        return step;
    }

    public int getSectionStart() {
        return sectionStart;
    }

    public int getSectionEnd() {
        return sectionEnd;
    }

    public String getCity() {
        return city;
    }

    public String getSector() {
        return sector;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public int getBillTotal() {
        return billTotal;
    }

    @Override
    public String toString() {
        return "Data{" +
            "city='" + city + '\'' +
            ", sector='" + sector + '\'' +
            ", unitPrice=" + unitPrice +
            ", billTotal=" + billTotal +
            '}';
    }
}
