package com.nhnacademy.repository;

import java.util.List;

public interface DataParser {
    List<Data> parse(String filePath);
}
