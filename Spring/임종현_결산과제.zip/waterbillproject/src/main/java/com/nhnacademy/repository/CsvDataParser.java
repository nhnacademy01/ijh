package com.nhnacademy.repository;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public class CsvDataParser implements DataParser{
    private final List<Data> dataList = new ArrayList<>();

    @Override
    public List<Data> parse(String filePath) {

        try (BufferedReader bufferedReader = Files.newBufferedReader(Paths.get(filePath))) {
            String line = "";
            String topLine = bufferedReader.readLine(); // 맨위에꺼 안쓰니깐 날림
            while ((line = bufferedReader.readLine()) != null) {
                String[] nextLine = line.split(",");
                dataList.add(new Data(Integer.parseInt(nextLine[0]), nextLine[1], nextLine[2], Integer.parseInt(nextLine[3]), Integer.parseInt(nextLine[4]), Integer.parseInt(nextLine[5]), Integer.parseInt(nextLine[6]), 0));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return dataList;
    }
}
