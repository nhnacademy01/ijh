package com.nhnacademy.service;

import com.nhnacademy.repository.Data;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DefaultReport implements Report {
    @Override
    public void report(List<Data> data) {
        for (Data data1 : data) {
            System.out.println(data1.toString());
        }
    }
}
