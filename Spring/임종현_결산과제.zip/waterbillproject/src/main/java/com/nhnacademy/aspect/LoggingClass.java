package com.nhnacademy.aspect;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;


@Aspect
@Component
public class LoggingClass {
    Log log = LogFactory.getLog(LoggingClass.class);

    @Around("execution(* com.nhnacademy..*.*(..))")
    public Object scoresLoadCheck(ProceedingJoinPoint pjp) throws Throwable {
        String methodName = pjp.getSignature().getName();
        StopWatch stopWatch = new StopWatch();
        try {
            stopWatch.start();
            return pjp.proceed();
        } finally {
            stopWatch.stop();
            log.info(stopWatch.prettyPrint());
            log.info("method name : " + methodName + "\n\n");
        }
    }
}
