package com.nhnacademy.service;

import com.nhnacademy.repository.Data;
import com.nhnacademy.repository.FeeTable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DefaultWaterBillService implements WaterBillService{
    FeeTable feeTable;

    public DefaultWaterBillService(FeeTable feeTable) {
        this.feeTable = feeTable;
    }

    @Override
    public List<Data> calculationPay(int usage) {
        String filePath = "src/main/resources/data/Tariff_20220331.csv";
        feeTable.load(filePath);
        List<Data> findData = feeTable.findAll(usage);
        List<Data> top5Data = new ArrayList<>();

        findData.stream()
            .sorted(Comparator.comparing(Data::getBillTotal))
            .limit(5)
            .forEach(top5Data::add);

        return top5Data;
    }
}