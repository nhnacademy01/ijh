package com.nhnacademy.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Repository;

@Repository
public class DefaultFeeTable implements FeeTable {
    private List<Data> dataList = new ArrayList<>();

    @Override
    public void load(String filePath) {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.nhnacademy")) {
            DataParser csvDataParser = context.getBean("csvDataParser", CsvDataParser.class);
            DataParser jsonDataParser = context.getBean("jsonDataParser", JsonDataParser.class);
            String extension = filePath.substring(filePath.lastIndexOf(".") + 1);

            if(extension.equals("json")) {
                dataList = jsonDataParser.parse(filePath);
            } else if(extension.equals("csv")) {
                dataList = csvDataParser.parse(filePath);
            }
        }
    }

    @Override
    public List<Data> findAll(int usage) {
        List<Data> resultData = new ArrayList<>();
        for (Data data : dataList) {
            if (usage <= data.getSectionEnd()) {
                resultData.add(new Data(data.getSeq(), data.getCity(), data.getSector(), data.getStep(), data.getSectionStart(), data.getSectionEnd(), data.getUnitPrice(), data.getUnitPrice()*usage));
            }
        }

        return resultData;
    }
}
