package com.nhnacademy;

import com.nhnacademy.service.DefaultReport;
import com.nhnacademy.service.DefaultWaterBillService;
import com.nhnacademy.service.Report;
import com.nhnacademy.service.WaterBillService;
import java.util.Objects;
import java.util.Scanner;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BootStrap {
    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.nhnacademy")) {
            Scanner scanner = new Scanner(System.in);
            WaterBillService defaultWaterBillService = context.getBean("defaultWaterBillService",
                DefaultWaterBillService.class);
            Report defaultReport = context.getBean("defaultReport", DefaultReport.class);

            while (true) {
                System.out.print("> ");
                String input = scanner.nextLine();
                if(Objects.equals(input, ""))
                    break;
                defaultReport.report(defaultWaterBillService.calculationPay(Integer.parseInt(input)));
            }
        }
    }
}
