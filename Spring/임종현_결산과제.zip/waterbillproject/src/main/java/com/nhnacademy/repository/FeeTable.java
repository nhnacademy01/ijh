package com.nhnacademy.repository;

import java.util.List;

public interface FeeTable {
    void load(String filePath);
    List<Data> findAll(int usage);
}
