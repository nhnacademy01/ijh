package com.nhnacademy.service;

import com.nhnacademy.repository.Data;
import java.util.List;

public interface Report {
    void report(List<Data> data);
}
