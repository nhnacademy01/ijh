package com.nhnacademy.service;

import com.nhnacademy.repository.Data;
import java.util.List;

public interface WaterBillService {
    List<Data> calculationPay(int usage);
}
