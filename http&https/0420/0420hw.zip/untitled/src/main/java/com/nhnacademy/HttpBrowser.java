package com.nhnacademy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HttpBrowser {
    private boolean verbose;
    private String method = "GET";
    private String url;
    Map<Integer, Header> headerMap = new HashMap<>();

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        HttpBrowser httpBrowser = new HttpBrowser();
        String[] input;
        System.out.print("$ ");
        input = scanner.nextLine().split(" ");

        httpBrowser.parse(input);
        httpBrowser.sendReq(httpBrowser.url, httpBrowser.method);
    }

    private void parse(String[] args) {
        if (!args[0].equals("scurl")) {
            return;
        }
        if(args[1].equals("-v")) {
            verbose = true;
        }

        for (int i = 1; i < args.length; i++) {
            if(args[i].equals("-X")){
                method = args[i+1];
            }
            if(args[i].equals("-H")){
                // args[i+1] : "X-Custom-Header: , args[i+2] : NA"
                args[i+1] = args[i+1].replace("\"", "");
                args[i+2] = args[i+2].replace("\"", "");
                headerMap.put(headerMap.size(), new Header(args[i+1].split(":")[0], args[i+2]));
            }
            if(i == args.length-1) {
                url = args[i];
            }
        }
    }

    private void sendReq(String urlString, String method) throws IOException {
        BufferedReader in = null;
        try {
            URL url = new URL(urlString);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod(method); // GET, POST

            // header setting
            for (int i = 0; i < headerMap.size(); i++) {
                con.setRequestProperty(headerMap.get(i).getKey(), headerMap.get(i).getValue());
            }

            in = new BufferedReader(new InputStreamReader(con.getInputStream(),
                StandardCharsets.UTF_8));
            String line;

            // print
            if(verbose) {
                while ((line = in.readLine()) != null) {
                    System.out.println(line);
                }
            }
        } finally {
            if(in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}