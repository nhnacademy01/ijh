package com.nhnacademy.clean;

public interface Discountale {
    long discount(long listPrice);
}
