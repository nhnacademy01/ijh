package com.nhnacademy.clean;

public class AccountService {
    String customerId;

    public String getAccountId() {
        return customerId;
    }
}
