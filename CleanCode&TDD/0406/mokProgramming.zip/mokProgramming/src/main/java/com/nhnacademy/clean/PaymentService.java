package com.nhnacademy.clean;

public class PaymentService  {
    AccountRepository accountRepository;

    PaymentService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    Receipt pay(long amount, String accountId) {
        if (amount < 0) {
            throw new NegativeAmountException("the amount should not negative.");
        }

        Account account = accountRepository.findByAccountId(accountId);
        if (account == null) {
            throw new NoAccountException();
        }

        long afterReward = account.useReward(amount); // 리워드 사용

        savePoint(amount);         // 적립금 저장

        SnsDummy dummy = new SnsDummy();
        // dummy.sendSns();
        receiptIssue(afterReward);
        if (account.hasCoupon()) {
            afterReward = (long) (account.useCoupon(afterReward));
        }
        return new Receipt(afterReward, account);
    }

    public String receiptIssue(long afteReward) {
        return afteReward + " ";
    }

    public long savePoint(long amount) {
        if (amount < 10000) {
            return (long) (amount * 0.1f);
        }
        return (long) (amount * 0.2f);
    }
}