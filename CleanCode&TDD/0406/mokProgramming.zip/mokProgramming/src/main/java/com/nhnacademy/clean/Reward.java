package com.nhnacademy.clean;

public class Reward {
}
