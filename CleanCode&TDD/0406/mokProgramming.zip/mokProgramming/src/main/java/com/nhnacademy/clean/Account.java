package com.nhnacademy.clean;

public class Account {
    private final String accountId;
    private long reward;
    private final Discountale coupon;

    public String getAccountId() {
        return accountId;
    }

    public Account(String accountId) {
        this(accountId, 0L);
    }

    public Account(String accountId, TenPercentCoupon coupon10) {
        this(accountId, 0L, coupon10);
    }

    public Account(String accountId, long reward) {
        this(accountId, reward, null);
    }

    public Account(String accountId, long reward, Discountale coupon) {
        this.accountId = accountId;
        this.reward = reward;
        this.coupon = coupon;
    }

    public long useReward(long amount) {
        return amount - this.reward;
    }

    public long getReward() {
        return reward;
    }

    public boolean hasCoupon() {
        return this.coupon != null;
    }

    public long useCoupon(long afterReward) {
        return this.coupon.discount(afterReward);
    }
}
