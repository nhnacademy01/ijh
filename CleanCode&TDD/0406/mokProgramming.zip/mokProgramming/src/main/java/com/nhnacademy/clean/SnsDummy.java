package com.nhnacademy.clean;

public class SnsDummy {
    public boolean sendSns(String message) {
        return true;
    }


    public boolean appPush() {
        return true;
    }

    public boolean sendEmailTo(String msg) {
        return true;
    }
}
