package com.nhnacademy.clean;

public class TenPercentCoupon implements Discountale {

    public long discount(long listPrice) {
        if (listPrice < 500) {
            return listPrice;
        }
        return (long) (listPrice * 0.9);
    }
}
