package com.nhnacademy.clean;

public class OneThousandCoupon implements Discountale{

    public long discount(long listPrice) {
        if (listPrice < 50_000) {
            return listPrice;
        }
        return (long)listPrice -1000L;
    }
}




// 마트전단지 쿠폰
