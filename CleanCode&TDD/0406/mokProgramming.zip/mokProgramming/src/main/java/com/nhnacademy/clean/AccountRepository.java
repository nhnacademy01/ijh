package com.nhnacademy.clean;

public class AccountRepository {

    public Account findByAccountId(String accountId) {
        return null;
    }
}
