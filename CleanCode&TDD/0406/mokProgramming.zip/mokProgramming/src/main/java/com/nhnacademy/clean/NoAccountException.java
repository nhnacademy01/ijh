package com.nhnacademy.clean;

public class NoAccountException extends RuntimeException {
    NoAccountException() {
        super("No account");
    }
}
