package com.nhnacademy.clean;

public class Receipt {
    private long payAmount;
    private Account account;

    public Receipt(long payAmount, Account account) {
        this.payAmount = payAmount;
        this.account = account;
    }

    public Account getAccount() {
        return account;
    }

    public long getPayAmount() {
        return payAmount;
    }
}
