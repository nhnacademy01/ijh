package com.nhnacademy.clean;

import static org.assertj.core.api.Assertions.*;
import static org.assertj.core.internal.bytebuddy.matcher.ElementMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class PaymentServiceTest {
    private AccountRepository repository;
    private PaymentService paymentService;
    private SnsDummy snsDummy;

    @BeforeEach
    void setUp() {
        repository = mock(AccountRepository.class);
        snsDummy = new SnsDummy();
        paymentService = new PaymentService(repository);
    }

    @DisplayName("고객의 계정 없으면 예외 발생")
    @Test
    void pay_noAccount_throwNoAccountException() {
        Account account = new Account("kihun", new TenPercentCoupon());
        when(repository.findByAccountId("kihun")).thenReturn(account);

        // 뭘 하는지 봐라
        assertThatThrownBy(() -> paymentService.pay(2_000L, "jh"))
                .isInstanceOf(NoAccountException.class)
                .hasMessage("No account");
    }

    @DisplayName("결재 금액이 유효해야함.(음수이면 안됨)")
    @Test
    void pay_invalidAmount() {
        assertThatThrownBy(() -> paymentService.pay(-1L, "jh"))
                .isInstanceOf(NegativeAmountException.class)
                .hasMessageContainingAll("amount", "not negative");
    }

    @DisplayName("실 결재 금액을 기준으로 적립율에 따라서 적립됨")
    @Test
    void pay_accordingToTheRate() {
        assertEquals(0, paymentService.savePoint(0L));
        assertEquals(300L, paymentService.savePoint(3_000L));
        assertEquals(2_400L, paymentService.savePoint(12_000L));
    }

    @DisplayName("SMS 알림 발생(Dummy). 만약 알림 발송이 실패해도, 결재는 정상적으로 완료.")
    @Test
    void pay_sendSnsfunction_checked() {
        assertTrue(snsDummy.sendSns("hi"));
    }

    @DisplayName("결재 완료 후 영수증 발행.")
    @Test
    void ReceiptIssuedAfterPayment() {
        Account account = new Account("coco", new TenPercentCoupon());
        when(repository.findByAccountId("coco")).thenReturn(account);

        Receipt receipt = paymentService.pay(1_000L, "coco");
        assertThat(receipt).isNotNull();
    }

    @ValueSource(longs = {999L, 1_000L, 1_001L})
    @DisplayName("결재 시 적림금을 사용할 수 있음")
    @ParameterizedTest
    void pay_usingReward(long reward) {
        PaymentService paymentService2 = new PaymentService(repository);

        // account 를 하나 만듦 (이미 적립금이 셋팅된 account)
        Account account = new Account("coco", reward);
        when(repository.findByAccountId("coco")).thenReturn(account);

        // 결재를 할거다.
        Receipt receipt = paymentService2.pay(1_000L, "coco");

        assertThat(receipt).isNotNull();
        assertThat(receipt.getAccount()).isNotNull();
        assertThat(receipt.getPayAmount()).isEqualTo(1_000L - reward);
    }

    @DisplayName("결재 완료 시 SMS 뿐만 아니라 앱 푸시(Dummy), 이메일도 전송")
    @Test
    void paySuccess_appPush_sendEmail() {
        assertTrue(snsDummy.sendSns("hi"));
        assertTrue(snsDummy.appPush());
        assertTrue(snsDummy.sendEmailTo("p@naver.com"));
    }

    @DisplayName(" 할인 쿠폰 적용")
    @Test
    void using_coupon() {
        PaymentService paymentService2 = new PaymentService(repository);
        Account account = new Account("coco", new TenPercentCoupon());
        when(repository.findByAccountId("coco")).thenReturn(account);

        // 결재를 할거다.
        Receipt receipt = paymentService2.pay(1_000L, "coco");

        assertThat(receipt).isNotNull();
        assertThat(receipt.getAccount()).isNotNull();
        assertThat(receipt.getPayAmount()).isEqualTo((long) (1_000L * 0.9));
    }
}
