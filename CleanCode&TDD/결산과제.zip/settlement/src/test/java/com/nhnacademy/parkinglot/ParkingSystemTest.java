package com.nhnacademy.parkinglot;

import static com.nhnacademy.parkinglot.CarType.COMPACT;
import static com.nhnacademy.parkinglot.CarType.NORMAL;
import static com.nhnacademy.parkinglot.CarType.TRUCK;
import static com.nhnacademy.parkinglot.MemberShip.PAYCO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ParkingSystemTest {

    @BeforeEach
    void setUp() {
    }

    @DisplayName("차가 들어오면 번호판을 인식(scan)합니다")
    @Test
    void parking_scanCarNumber() {
        Car car1 = new Car(1234, COMPACT);
        ParkingLot parkingLot1 = new ParkingLot();
        parkingLot1.enter(car1, 1);

        // 주차장에 1234번호판의 자동차가 잘 저장되어있는지 확인
        assertThat(parkingLot1.findCar(1234).getCarNumber()).isEqualTo(1234);
    }

    @DisplayName("차를 특정 주차구역(ParkingSpaces)에 주차합니다.")
    @Test
    void parking_parkingSpaces() {
        Car car1 = new Car(1234, COMPACT);
        ParkingLot parkingLot1 = new ParkingLot();
        ParkingSpace a_1 = new ParkingSpace();

        a_1.parking(car1, parkingLot1);

        // a_1 구역에 자동차가 잘 주차되었는지 확인
        assertThat(a_1.getCar()).isEqualTo(car1);
    }

    @DisplayName("만약 돈이 없으면 나갈 수 없습니다.")
    @Test
    void noExit_lackOfMoney() {
        Car car1 = new Car(1234, COMPACT);
        User user1 = new User(car1, 0); // 초기자금 0원

        assertThatThrownBy(() -> user1.pay(1000))
            .isInstanceOf(NotEnoughMoneyException.class)
            .hasMessageContaining("Fail");
    }

    @DisplayName("주차장에서 차가 나간다. 차가 나갈려면 주차 시간만큼 결제를 해야한다.")
    @Test
    void exit_paymentToTime() {
        Car car1 = new Car(1234, NORMAL);
        ParkingLot parkingLot = new ParkingLot();
        User user1 = new User(car1, 25000);

        parkingLot.enter(car1, 1);
        parkingLot.exit(user1, 1); // 시간은 현재 1일 6시간 1분으로 셋팅되어있음.

        assertEquals(0, user1.getMoney()); // 결재하고 남은 user의 잔액이 정확한지 확인인
    }

    @DisplayName("주차장 입구가 3개 입니다.")
    @Test
    void entranceCount_isThree() {
        ParkingLot parkingLot = new ParkingLot();
        parkingLot.addEntranceCount(2); // 기본값은 1개

        assertThat(parkingLot.getEntranceCount()).isEqualTo(3);
    }

    @DisplayName("주차장 출구도 3개 입니다.")
    @Test
    void exitCount_isThree() {
        ParkingLot parkingLot = new ParkingLot();
        parkingLot.addExitCount(2);

        assertThat(parkingLot.getExitCount()).isEqualTo(3);
    }

    @DisplayName("경차의 경우 요금이 50% 감면됩니다.")
    @Test
    void payment_compactCar_50PercentDiscount() {
        Car spark = new Car(1234, COMPACT);
        ParkingLot parkingLot = new ParkingLot();
        User user1 = new User(spark, 12500);
        parkingLot.enter(spark, 1);
        parkingLot.exit(user1, 1); // 시간은 현재 1일 6시간 1분으로 셋팅되어있음.

        assertEquals(0, user1.getMoney()); // 원래는 25000원인데 50% 감면되어서 12500원이 나옴. (초기자금 12500원)
    }

    @DisplayName("주차장에 대형차(트럭 등)는 주차할 수 없습니다.")
    @Test
    void truckParking_makeException() {
        Car truck = new Car(1234, TRUCK);
        ParkingLot parkingLot = new ParkingLot();

        assertThatThrownBy(() -> parkingLot.enter(truck, 1))
            .isInstanceOf(CarTypeNotMatchException.class)
            .hasMessageContaining("Not Match");
    }

    @DisplayName("사용자(User)가 Payco 회원인 경우에는 주차 요금이 10% 할인됩니다.")
    @Test
    void paycoUser_discountTenPercent() {
        ParkingLot parkingLot = new ParkingLot();
        Car sonata = new Car(1234, NORMAL);
        User paycoUser = new User(sonata, 25000);

        paycoUser.setMemberShip(PAYCO);

        parkingLot.enter(sonata, 1);
        parkingLot.exit(paycoUser, 1); // 시간은 현재 1일 6시간 1분으로 셋팅되어있음.

        assertEquals(2500, paycoUser.getMoney()); // 원래는 25000원인데 10% 감면되어서 2500원 남음.
    }

    @DisplayName("3시간 주차 후 2시간 주차권을 제시하면, 1시간 요금만 정산하면 됩니다.")
    @Test
    void parkingTicket_TwoHour() {
        Car sonata = new Car(1234, NORMAL);
        ParkingLot parkingLot = new ParkingLot();
        User anonymousUser = new User(sonata, 7000);

        anonymousUser.setTicket(2);

        parkingLot.enter(sonata, 1);
        parkingLot.exit(anonymousUser, 1); // 시간은 현재 1일 6시간 1분으로 셋팅되어있음.

        assertEquals(0, anonymousUser.getMoney()); // 원래는 25000원인데
    }
}
