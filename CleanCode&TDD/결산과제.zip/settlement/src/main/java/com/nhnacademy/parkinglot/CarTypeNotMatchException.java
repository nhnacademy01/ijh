package com.nhnacademy.parkinglot;

public class CarTypeNotMatchException extends RuntimeException{
    public CarTypeNotMatchException(String message) {
        super(message);
    }
}
