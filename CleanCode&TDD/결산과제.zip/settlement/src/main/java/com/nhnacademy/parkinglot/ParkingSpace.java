package com.nhnacademy.parkinglot;

public class ParkingSpace {
    private Car car;

    public void parking(Car car, ParkingLot parkingLot) {
        this.car = car;
        parkingLot.fillSpace(this);
    }
    public void unParking(ParkingLot parkingLot) {
        this.car = null;
        parkingLot.emptySpace(this);
    }

    // getter
    public Car getCar() {
        return this.car;
    }
}
