package com.nhnacademy.parkinglot;

public enum MemberShip {
    PAYCO,
    ANONYMOUS,
    OTHERS,
}
