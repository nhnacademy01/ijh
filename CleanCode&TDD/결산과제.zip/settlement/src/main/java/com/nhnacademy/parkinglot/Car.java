package com.nhnacademy.parkinglot;

public class Car {
    private User owner;
    private final int carNumber;
    private final CarType carType;

    public Car(int carNumber, CarType carType) {
        this.carNumber = carNumber;
        this.carType = carType;
    }
    public User findUser() {
        return this.owner;
    }

    // setter
    public void setOwner(User owner) {
        this.owner = owner;
    }
    // getter
    public int getCarNumber() {
        return this.carNumber;
    }
    public CarType getCarType() {
        return carType;
    }
}
