package com.nhnacademy.parkinglot;

public enum CarType {
    COMPACT,
    TRUCK,
    NORMAL,
}
