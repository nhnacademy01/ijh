package com.nhnacademy.parkinglot;

import java.time.LocalTime;
import java.util.HashMap;

public class ParkingSystem {
    ParkingLot parkingLot;
    HashMap<Integer, LocalTime> carTime = new HashMap<>();
    int dayCount = 1;
    LocalTime time = LocalTime.of(6, 1, 0);

    public ParkingSystem(ParkingLot parkingLot) {
        this.parkingLot = parkingLot;
    }
    public void timeCheck(int carNumbers) {
        carTime.put(carNumbers, time);
    }

    public int getPrice(int carNumber) {
        LocalTime tempTime = carTime.get(carNumber);
        int min = tempTime.getMinute() + tempTime.getHour() * 60;
        int sec = tempTime.getSecond() + min * 60;
        int payment = 0;

        payment += dayCount * 15000;
        // 최초 30분
        if (sec <= 1800) {
            return payment;
        }
        // 30분 ~ 1시간
        if (sec <= 3600) {
            return 1000;
        }
        // 6시간 이상주차시
        if (sec >= 21600) {
            payment += 10000;
            return payment;
        }
        // 10분에서 1초라도 지났는지 확인
        if ((sec-3600) % 600 != 0) {
            payment += 500;
        }
        payment += (sec-3600) / 600 * 500 + 1000;

        return payment;
    }

}
