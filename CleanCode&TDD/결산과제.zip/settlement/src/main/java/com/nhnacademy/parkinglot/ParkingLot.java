package com.nhnacademy.parkinglot;
import static com.nhnacademy.parkinglot.CarType.TRUCK;

import java.util.ArrayList;

public class ParkingLot {
    private final ParkingSystem ps = new ParkingSystem(this);
    ArrayList<Car> cars = new ArrayList<>();
    ArrayList<ParkingSpace> spaces = new ArrayList<>();
    ArrayList<Entrance> entrances = new ArrayList<>();
    ArrayList<Exit> exits = new ArrayList<>();

    // init
    public ParkingLot() {
        entrances.add(new Entrance(1));
        exits.add(new Exit(1));
    }

    // 공간은 주차장에서 채울수 있는것이 아닐까?
    public void fillSpace(ParkingSpace space) {
        spaces.add(space);
    }
    public void emptySpace(ParkingSpace space) {
        spaces.remove(space);
    }
    public void enter(Car car, int entranceNumber) {
        if (car.getCarType() == TRUCK) {
            throw new CarTypeNotMatchException("Not Match CarType");
        }
        entrances.get(entranceNumber-1).enterParkingLot(car);
    }
    public void exit(User user1, int exitNumber) {
        exits.get(exitNumber-1).exitParkingLot(user1);
    }

    // getter
    public int getEntranceCount() {
        return entrances.size();
    }
    public int getExitCount() {
        return exits.size();
    }
    public Car findCar(int carNumber) {
        for (Car car : cars) {
            if (car.getCarNumber() == carNumber) {
                return car;
            }
        }
        return null;
    }

    // setter
    public void addEntranceCount(int n) {
        for (int i = 0; i < n; i++) {
            entrances.add(new Entrance(n));
        }
    }
    public void addExitCount(int n) {
        for (int i = 0; i < n; i++) {
            exits.add(new Exit(n));
        }
    }

    // class
    class Entrance {
        String name;
        public Entrance(int i) {
            this.name = i + "번 입구";
        }

        public void enterParkingLot(Car car) {
            scan(car);
            cars.add(car);
        }

        private void scan(Car car) {
            ps.timeCheck(car.getCarNumber());
        }
    }
    class Exit {
        String name;
        public Exit(int n) {
            this.name = n + "번 입구";
        }

        // 주차장에서 나가면 어떤 행동을 해야하나?
        // 계산을하고, -> 요금이 얼마라고 알려주어야겠지. -> 요금은 어떻게 구하지?
        // -> 그건 주차장에서 자동차를scan할때(입고될때 scan해주어야겠지?) 입차시간정보를 주차장 서비스에서 저장했어야겠지.
        // scan은 자동차가 parking할때 이루어져야겠지
        // 주차장에 저장되어 있던 자동차번호정도를 지워주어야겠지?
        public void exitParkingLot(User user) {
            user.pay(ps.getPrice(user.getCar().getCarNumber()));
            cars.remove(user.getCar());
        }
    }
}