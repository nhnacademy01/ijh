package com.nhnacademy.parkinglot;

import static com.nhnacademy.parkinglot.CarType.COMPACT;
import static com.nhnacademy.parkinglot.MemberShip.ANONYMOUS;
import static com.nhnacademy.parkinglot.MemberShip.PAYCO;

public class User {
    private final Car car;
    private MemberShip memberShip;
    private int money;
    private int ticket;

    public User(Car car, int initMoney) {
        this.car = car;
        this.money = initMoney;
        this.memberShip = ANONYMOUS;
        this.ticket = 0;

        this.car.setOwner(this);
    }

    public MemberShip getMemberShip() {
        return memberShip;
    }
    public void pay(int money) {
        if (this.car.getCarType() == COMPACT) {
            money /= 2;
        }
        if (this.memberShip == PAYCO) {
            money *= 0.9;
        }
        if (this.money < money) {
            throw new NotEnoughMoneyException("Fail Payment. User money : "
                + this.money + ", payment : " + money);
        }
        this.money -= money;
    }

    // getter
    public Car getCar() {
        return car;
    }
    public int getMoney() {
        return money;
    }
    public int getTicket() {
        return ticket;
    }

    // setter
    public void setMemberShip(MemberShip memberShip) {
        this.memberShip = memberShip;
    }
    public void setTicket(int ticket) {
        this.ticket = ticket;
    }
}
