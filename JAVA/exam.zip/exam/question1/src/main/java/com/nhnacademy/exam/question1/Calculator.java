package com.nhnacademy.exam.question1;
import java.util.stream.IntStream;

class CalculatorOnShell {
    public static void main(String[] args) {
        int n = 20;
        Calculator calculator = new Calculator();
        System.out.println(calculator.sum_integers(1, 10));
        System.out.println(calculator.product_integers(1, 10));

//        System.out.println(calculator.sum());
//        IntStream.range(1,10).forEach(i -> System.out.println(i));
    }
}

public class Calculator {
    public int fold(int identity, Glue glue, int[] xs) {
        int result = identity;
        for (int x : xs) {
            result = glue.calculator(result, x);
        }
        return result;
    }

    public int sum(int[] xs) {
        return fold(0, Integer::sum, xs);
    }

    private int product(int[] xs) {
        return fold(1, (a, b) -> a * b, xs);
    }

    int sum_integers(int start, int end) {
        return sum(IntStream.range(start, end + 1).toArray());
    }

    int product_integers(int start, int end) {
        return product(IntStream.range(start, end).toArray());
    }

//    double[] randomSumInt(int start, int end) {
//        double[] result = new double[end];
//        for (int i = start; i < end; i++) {
//            result[i] = Math.random();
//        }
//        return result;
//    }
}

interface Glue {
    int calculator(int a, int b);
}