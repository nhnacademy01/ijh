package com.nhnacademy.exam.question3;

import java.math.BigInteger;
import java.util.ArrayList;

public class MonteCarlo {
    public static void main(String[] args) {
        MonteCarlo monteCarlo = new MonteCarlo();
        System.out.println(monteCarlo.quess_pi(100000));
    }

    public double quess_pi(int n_trials) {
        return Math.sqrt( 6 / monte_carlo(n_trials, ()-> {
            BigInteger b1 = BigInteger.valueOf((int)(Math.random() * 999) + 1);
            BigInteger b2 = BigInteger.valueOf((int)(Math.random() * 999) + 1);
            BigInteger gcd = b1.gcd(b2);
            return gcd.intValue() == 1;
        }));
    }

    public double monte_carlo(int n_trials, dirichlet_test binary_sampler) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        int result = 0;
        for (int i = 0; i < n_trials; i++) {
            if(binary_sampler.truths())
                arrayList.add(1);
            else
                arrayList.add(0);
            result += arrayList.get(i);
        }
        return (double) result / n_trials;
    }
}

interface dirichlet_test {
    boolean truths();
}