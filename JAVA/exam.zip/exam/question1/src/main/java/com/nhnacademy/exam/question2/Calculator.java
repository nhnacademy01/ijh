package com.nhnacademy.exam.question2;

import java.util.function.Supplier;

public class Calculator {

    // 전달받은 매개변수를 반환하는 함수를 반환
    public Supplier<Integer> delay(int v) {
        return () -> v;
    }

    public int force(Supplier<Integer> v) {
        return v.get();
    }

    Pair<Object,Object> emptyStream = null;
    public Pair<Object,Object> stream(int x, int y) {
        return new Pair<>(x, delay(y));
    }

    public int head(Pair<Object,Object> stream) {
        return (int) stream.getHead();
    }

    public int tail(Pair<Object,Object> stream) {
        return force((Supplier<Integer>) stream.getTail());
    }

    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        Supplier<Integer> delayReturn = calculator.delay(10);
        int i = calculator.force(delayReturn);

        System.out.println(i);
    }
}

class Pair<T1, T2> {
    private final T1 head;
    private final T2 tail;

    public Pair(T1 head, T2 tail) {
        this.head = head;
        this.tail = tail;
    }

    public T1 getHead() {
        return head;
    }

    public T2 getTail() {
        return tail;
    }
}