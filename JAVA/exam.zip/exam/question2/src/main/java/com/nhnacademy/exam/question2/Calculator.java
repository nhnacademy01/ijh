package com.nhnacademy.exam.question2;

interface BinaryOp {
    int apply(int right, int left);
}

class Adder implements BinaryOp {
    @Override
    public int apply(int right, int left) {
        return right + left;
    }
}

class Multiplier implements BinaryOp {
    @Override
    public int apply(int right, int left) {
        return right * left;
    }
}

class Calculator {
    public static void main(String[] args) {
        System.out.println(Sigma.calc(1,10,1));
        System.out.println(Pi.calc(1,10,1));
    }

    public static int accumulate(BinaryOp binder, int init, int begin, int end, int step) {
        int result = init;

        for(int next = begin; next <= end; next += step) {
            result = binder.apply(result, next);
        }
        return result;
    }
}

class Sigma {
    public static int calc(int begin, int end, int step) {
        return Calculator.accumulate( new Adder(), 0, begin, end, step);
    }
}

class Pi {
    public static int calc(int begin, int end, int step) {
        return Calculator.accumulate( new Multiplier(), 1, begin, end, step);
    }
}