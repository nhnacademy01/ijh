package com.nhnacademy.exam.question1;

class Calculator {
    public static void main(String[] args) {
        System.out.println(Calculator.sigma(1,10,1));
        System.out.println(Calculator.pi(1,10,1));
    }

    public static int sigma(int begin, int end, int step) {
        int result = begin;
        Adder adder = new Adder();
        for(int i = begin+step; i <= end; i += step) {
            result = adder.apply(result, i);
        }
        return result;
    }

    public static int pi(int begin, int end, int step) {
        int result = begin;
        Multiplier multiplier = new Multiplier();
        for(int i = begin+step; i <= end; i += step) {
            result = multiplier.apply(result, i);
        }
        return result;
    }
}

class Adder {
    public int apply(int right, int left) {
        return right + left;
    }
}

class Multiplier {
    public int apply(int right, int left) {
        return right * left;
    }
}